import"./CR08TgbQ.js";const e=""+new URL("logo.BxpwT-bv.webp",import.meta.url).href;export{e as o};
