import{ae as a,s as p}from"./Bcvng2S8.js";const d=a((e,o)=>{const t=p();o.path!==e.path&&t.onUpdateLoading(!0)});export{d as default};
