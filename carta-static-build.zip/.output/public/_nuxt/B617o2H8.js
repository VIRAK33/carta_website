import{ae as a,s as p}from"./DLbEtaiG.js";const d=a((e,o)=>{const t=p();o.path!==e.path&&t.onUpdateLoading(!0)});export{d as default};
