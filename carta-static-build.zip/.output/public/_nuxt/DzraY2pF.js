import"./Bcvng2S8.js";const e=""+new URL("logo.BxpwT-bv.webp",import.meta.url).href;export{e as o};
