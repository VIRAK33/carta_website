import"./yqhIt5z2.js";const e=""+new URL("logo.BxpwT-bv.webp",import.meta.url).href;export{e as o};
