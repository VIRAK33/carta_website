import{ae as a,s as p}from"./D4gr-QbI.js";const d=a((e,o)=>{const t=p();o.path!==e.path&&t.onUpdateLoading(!0)});export{d as default};
