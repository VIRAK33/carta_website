import"./D3tPy1oU.js";const r=""+new URL("AI_Microsoft_Research_Header.DmW9DP40.webp",import.meta.url).href;export{r as b};
